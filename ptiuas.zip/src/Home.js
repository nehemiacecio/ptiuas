import React, { Component } from 'react'

export class Home extends Component {
    render() {
        return (
            <div>
                <h2>Covid</h2>
            </div>
        )
    }
}

export default Home
