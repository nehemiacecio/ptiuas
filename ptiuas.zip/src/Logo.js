import React, { Component } from 'react'

export class Logo extends Component {
    render() {
        return (
            <div className="logo" >
            <h1> Covid-19</h1>
            
            </div>
        )
    }
}

export default Logo
